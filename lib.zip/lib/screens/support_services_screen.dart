import 'package:flutter/material.dart';

class SupportServicesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Servicios de Apoyo"),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          _buildServiceCard(
              "Asesoría Académica", "Soporte en temas académicos y tutorías."),
          _buildServiceCard("Apoyo Emocional",
              "Servicios de orientación y apoyo psicológico."),
        ],
      ),
    );
  }

  Widget _buildServiceCard(String title, String description) {
    return Card(
      margin: EdgeInsets.only(bottom: 16.0),
      child: ListTile(
        title: Text(title),
        subtitle: Text(description),
      ),
    );
  }
}
