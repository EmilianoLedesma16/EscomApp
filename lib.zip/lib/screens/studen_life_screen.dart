import 'package:flutter/material.dart';

class StudentLifeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Vida Estudiantil"),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          _buildLifeCard("Club de Programación",
              "Actividades de programación y competiciones."),
          _buildLifeCard(
              "Eventos de Tecnología", "Eventos de networking y tecnología."),
        ],
      ),
    );
  }

  Widget _buildLifeCard(String title, String description) {
    return Card(
      margin: EdgeInsets.only(bottom: 16.0),
      child: ListTile(
        title: Text(title),
        subtitle: Text(description),
      ),
    );
  }
}
