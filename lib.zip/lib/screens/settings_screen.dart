import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Configuración"),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          SwitchListTile(
            title: Text("Notificaciones"),
            value: true,
            onChanged: (val) {},
          ),
          SwitchListTile(
            title: Text("Modo Oscuro"),
            value: false,
            onChanged: (val) {},
          ),
        ],
      ),
    );
  }
}
