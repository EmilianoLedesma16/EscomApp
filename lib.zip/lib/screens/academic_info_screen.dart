import 'package:flutter/material.dart';

class AcademicInfoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Información Académica"),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          _buildAcademicCard("Ingeniería en Sistemas Computacionales",
              "Descripción breve de la carrera..."),
          _buildAcademicCard("Ingeniería en Inteligencia Artificial",
              "Descripción breve de la carrera..."),
        ],
      ),
    );
  }

  Widget _buildAcademicCard(String title, String description) {
    return Card(
      margin: EdgeInsets.only(bottom: 16.0),
      child: ListTile(
        title: Text(title),
        subtitle: Text(description),
        trailing: Icon(Icons.arrow_forward),
        onTap: () {
          // Navegar a la pantalla de detalle de la carrera
        },
      ),
    );
  }
}
