import 'package:flutter/material.dart';

class CampusMapScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Mapa del Campus"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Selecciona el nivel del campus"),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Mostrar mapa del nivel 1
              },
              child: Text("Nivel 1"),
            ),
            ElevatedButton(
              onPressed: () {
                // Mostrar mapa del nivel 2
              },
              child: Text("Nivel 2"),
            ),
          ],
        ),
      ),
    );
  }
}
