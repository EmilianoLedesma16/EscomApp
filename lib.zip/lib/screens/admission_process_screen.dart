import 'package:flutter/material.dart';

class AdmissionProcessScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Proceso de Admisión"),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          _buildProcessStep("Paso 1", "Completar formulario de admisión"),
          _buildProcessStep("Paso 2", "Enviar documentación requerida"),
          _buildProcessStep("Paso 3", "Presentar examen de admisión"),
          _buildProcessStep("Paso 4", "Esperar resultados"),
        ],
      ),
    );
  }

  Widget _buildProcessStep(String title, String description) {
    return Card(
      margin: EdgeInsets.only(bottom: 16.0),
      child: ListTile(
        title: Text(title),
        subtitle: Text(description),
      ),
    );
  }
}
